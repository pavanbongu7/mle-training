# mle-training

1.open nonstandard code

2.pick the algorithm 

3.get the predictions